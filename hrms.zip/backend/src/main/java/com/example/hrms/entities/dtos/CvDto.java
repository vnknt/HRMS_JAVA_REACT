package com.example.hrms.entities.dtos;

import java.awt.List;

public class CvDto {

	private String candidateName;
	private String githubUrl;
	
	
	
	
	
}
