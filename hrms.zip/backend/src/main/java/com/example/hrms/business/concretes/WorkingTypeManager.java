package com.example.hrms.business.concretes;

import java.util.List;

import com.example.hrms.core.concretes.utilities.results.Result;
import com.example.hrms.core.concretes.utilities.results.SuccessResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hrms.business.abstracts.WorkingTypeService;
import com.example.hrms.core.concretes.utilities.results.DataResult;
import com.example.hrms.core.concretes.utilities.results.SuccessDataResult;
import com.example.hrms.dataAccess.abstracts.WorkingTypeDao;
import com.example.hrms.entities.concretes.WorkingType;
@Service
public class WorkingTypeManager implements WorkingTypeService {
	
	private WorkingTypeDao workingTypeDao;
	
	
	@Autowired
	public WorkingTypeManager(WorkingTypeDao workingTypeDao) {
		this.workingTypeDao = workingTypeDao;
	}
	
	
	
	@Override
	public DataResult<List<WorkingType>> getAll() {
		
		return new SuccessDataResult<List<WorkingType>>(this.workingTypeDao.findAll());
		
	}

	@Override
	public Result add(WorkingType workingType) {
		workingTypeDao.save(workingType);
		return new SuccessResult();
	}


}
