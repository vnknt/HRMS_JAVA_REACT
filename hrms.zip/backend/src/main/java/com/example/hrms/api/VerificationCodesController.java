package com.example.hrms.api;

public class VerificationCodesController {

}
