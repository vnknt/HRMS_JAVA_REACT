export default class Constants{


    constructor(){
        
    }

    static getApiUrl(){
        let api_url = "http://localhost:8080/api/"

        return api_url;
    }



}