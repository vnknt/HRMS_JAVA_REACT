import React from 'react'

export default function Forbidden() {
    return (
        <div>
            <h2 className='mt-5 pt-5 mb-5'>BU SAYFAYI GÖRMEYE YETKİNİZ YOK !!!
                </h2>
        </div>
    )
}
