const Actions = {
    USER_LOGIN:"USER_LOGIN",
    USER_LOGOUT:"USER_LOGOUT"


}

export default Actions;