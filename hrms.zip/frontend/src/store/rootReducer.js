import {userReducer} from './reducers/userReducer';

import { combineReducers } from "redux"

const rootReducer = combineReducers({
    
    user:userReducer

})

export default rootReducer;