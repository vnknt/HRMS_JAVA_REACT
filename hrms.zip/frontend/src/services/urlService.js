export default class UrlService{

    static getApiUrl(){
        return "http://localhost:8080/api/";
    }

}