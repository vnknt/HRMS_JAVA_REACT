export const url = "http://localhost:8080";
export const apiUrl = process.env.REACT_APP_API_URL;
